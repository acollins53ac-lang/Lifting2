# Lift — setup & data reference

## 1. Deploy to GitHub Pages

1. Create a new repo on GitHub — public, name it whatever (`lift` works).
2. Upload all six files to the repo root: `index.html`, `sw.js`,
   `manifest.webmanifest`, `icon-180.png`, `icon-192.png`, `icon-512.png`.
   Drag them into the "Add file → Upload files" box, then commit.
3. Repo **Settings → Pages**. Under *Source* pick **Deploy from a branch**,
   branch `main`, folder `/ (root)`. Save.
4. Wait about a minute. Your URL appears at the top of that same Pages screen:
   `https://<username>.github.io/<repo>/`

Every path in the app is relative (`./`), so it works fine under that subpath.

## 2. Add to your iPhone home screen

Open the URL **in Safari** — not Chrome, iOS only allows Safari to install PWAs.
Share button → **Add to Home Screen** → Add.

Launch it from the home screen icon and it runs full-screen with no browser
chrome, works offline, and keeps its own storage.

One caveat worth knowing: iOS clears site data for PWAs after roughly two weeks
of no use. Export a JSON backup from Settings now and then if you go quiet.

## 3. Your data, in plain English

Everything lives in IndexedDB on the phone. Nothing leaves the device.

**`sessions`** — one record per completed workout:
- `id` — timestamp when you hit Finish, doubles as the unique key
- `date` — `YYYY-MM-DD`
- `day` — `"A"` or `"B"`
- `block`, `weekInBlock`, `deload`, `wave` — where in the program it happened
- `exercises[]` — each with `slotId` (which movement slot), `exId` (which
  exercise filled it), `name`, and `logged[]` = `[{weight, reps}, …]`

The `slotId` / `exId` split is the important bit. `slotId` is the movement
pattern, `exId` is the specific exercise that day. That's what lets you swap
machines mid-session and still see one continuous progress line for the pattern.

**`bodyweights`** — keyed by date: `{date, lbs}`. One per week.

**`kv`** — everything else as key/value pairs: `settings`, `pins`
(slots you've frozen), `deloads` (list of week numbers you marked), `startDate`,
`active` (a workout in progress, so closing the app mid-session loses nothing),
and `timer`.

Export writes all of it as JSON with a `schema_version` field, so future
versions can migrate old backups.

## 4. Updating the app later

Edit `index.html` in the GitHub web editor (open the file, pencil icon, commit)
or push from your machine. Then **bump the `CACHE` constant in `sw.js`** —
`lift-v1` → `lift-v2`. Without that bump the service worker keeps serving the
old cached copy and you'll wonder why nothing changed.

Force a refresh on the phone by closing the app from the app switcher and
reopening it.
